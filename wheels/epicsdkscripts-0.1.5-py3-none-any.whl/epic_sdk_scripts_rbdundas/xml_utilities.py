"""
Author: Robert Dundas
License: Proprietary - Permissive use for client integration only
Date: 6/12/2024
Copyright 2024 - All Rights Reserved

This code was written and is owned in its entirety, by Rob Dundas
This code will be used for the purpose of expediting the
processing of records to and from the Epic SDK to a client's application.

All ownership, rights and privileges are retained by the author. Use
of the code is restricted to the API (Application Programming Interface)
integration between Epic (SDK) and the client's specific use application.
Permission to use this code by any clients who have not yet been identified
is restricted for that purpose and that specific client engagement. No other use, distribution,
resale, modification, or transfer is permitted without the expressed agreement
from the author.

The client recognizes that this specific program is separate and distinct
from other code within this application that was completed under a work-for-hire
contract. It was copied into a client solution to deliver a functional product
with tested programs as efficiently as possible.
"""
import re
from pathlib import Path
from lxml import etree
from collections import Counter


BASE_DIR = Path(__file__).resolve().parent


def recursively_empty(e):
    if e.text is not None:
        return False
    return all((recursively_empty(c) for c in e.iterchildren()))


def get_namespaces(xml):
    namespaces = {}
    xml_str = None
    try:
        xml_str = etree.tostring(xml, encoding='unicode')
    except :
        pass
    ns_list = re.findall(r'xmlns:(.*?)=(".*?")', xml_str)
    for each in ns_list:
        namespaces[each[0]] = each[1].replace('"', '')
    return namespaces


def clean_xml(xml):
    context = etree.iterwalk(xml.getroot())
    for action, elem in context:

        elem.tail = None

        if elem.text is not None:
            elem.text = elem.text.replace('\n', '').strip()
            if elem.text == '':
                elem.text = None

        parent = elem.getparent()
        if recursively_empty(elem):
            parent.remove(elem)

    root = xml.getroot()
    for element in root.xpath(".//*[not(node())]"):
        element.getparent().remove(element)

    return xml


def dict_to_xml(object_type, in_dict: dict, method) -> str:
    xml = etree.parse(f'{BASE_DIR}/xml/{method.lower()}_{object_type.lower()}.xml')

    def get_element_from_xml(tag_name):
        expr = "//*[local-name() = $name]"
        element = xml.xpath(expr, name=tag_name)
        if element is None or len(element) == 0:
            element = xml.xpath(expr, name=f'{tag_name}Object')
        return element

    def copy_nodes_for_children(_children, _child_xml):
        if len(list(_children)) > 1:
            for i in range(len(list(_children)) - 1):
                _sibling = etree.fromstring(etree.tostring(_child_xml))
                _child_xml.getparent().append(_sibling)
                i += 1

    def update_element_with_value(element, field):
        if isinstance(field, str) and field != '':
            element.text = field
        elif isinstance(field, int) and field is not None:
            element.text = str(field)
        elif isinstance(field, bool):
            if field == True:
                element.text = 'true'
            elif field == False:
                element.text = 'false'
            else:
                element = ''
        return element

    def convert_dict_to_xml(_dict: dict, iteration_number):
        for key, value in _dict.items():
            element = get_element_from_xml(key)
            if isinstance(value, list) and len(value) > 0:
                _child_element = element[0].getchildren()[iteration_number]
                copy_nodes_for_children(value, _child_element)
                for i, item in enumerate(value):
                    child = xml.findall(f'.//{_child_element.tag}')[i]
                    if child is not None:
                        convert_dict_to_xml(item, i)
            elif isinstance(value, dict):
                convert_dict_to_xml(value, iteration_number)
            else:
                update_element_with_value(element[iteration_number], value)
    convert_dict_to_xml(in_dict, 0)
    return xml


def xml_to_dict(xml, object_type) -> list:

    def get_element_from_xml(tag_name):
        expr = "//*[local-name() = $name]"
        element = xml.xpath(expr, name=tag_name)
        if element is None:
            element = xml.xpath(expr, name=f'{tag_name}Object')
        return element

    def is_list(child, parent):
        children = child.findall('./*')
        child_list = []
        for child in children:
            child_list.append(child.tag)
        counter = Counter(child_list)
        result = [i for i, j in counter.items() if j > 1]
        if result:
            return True
        else:
            return False

    def get_list(child):
        children = child.findall('./*')
        return children

    def convert_xml_to_dict(element) -> dict:
        result = {}
        for child in element:
            tag = etree.QName(child).localname
            if is_list(child, element):
                list_tag = etree.QName(child).localname
                if list_tag not in result.keys():
                    result[list_tag] = []
                children = get_list(child)
                for each in children:
                    child_tag = etree.QName(each).localname
                    _child = {
                        child_tag: convert_xml_to_dict(each)
                    }
                    result[list_tag].append(_child)
            elif len(child) > 0:
                result[tag] = convert_xml_to_dict(child)
            else:
                tag = etree.QName(child).localname
                if child.text:
                    result[tag] = child.text.strip()
        return result

    _elements = get_element_from_xml(object_type)
    _objects = []
    for _element in _elements:
        _object = {
            object_type: convert_xml_to_dict(_element)
        }
        _objects.append(_object)
    return _objects


def prepare_soap_xml_from_sdk(filename):
    out_xml = open(Path(f'{BASE_DIR}/xml', filename), 'w')
    with open(Path(f'{BASE_DIR}/xml', f'soap_{filename}')) as file:
        for line in file:
            if '<!--Optional:-->' in line:
                line_out = None
            elif '>?<' in line:
                line_out = line.replace('>?<', '><')
            elif '<!--Zero or more repetitions:-->' in line:
                line_out = line.replace('<!--Zero or more repetitions:-->', '')
            else:
                line_out = line
            if line_out:
                out_xml.write(line_out)
        file.close()
        out_xml.close()


if __name__ == '__main__':
    filename = 'get_commercialapplication_status.xml'
    prepare_soap_xml_from_sdk(filename)
