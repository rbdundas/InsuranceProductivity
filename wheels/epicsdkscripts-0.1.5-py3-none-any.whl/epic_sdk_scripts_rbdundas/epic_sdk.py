"""
Author: Robert Dundas
License: Proprietary - Permissive use for client integration only
Date: 6/12/2024
Copyright 2024 - All Rights Reserved

This code was written and is owned in its entirety, by Rob Dundas
This code will be used for the purpose of expediting the
processing of records to and from the Epic SDK to a client's application.

All ownership, rights and privileges are retained by the author. Use
of the code is restricted to the API (Application Programming Interface)
integration between Epic (SDK) and the client's specific use application.
Permission to use this code by any clients who have not yet been identified
is restricted for that purpose and that specific client engagement. No other use, distribution,
resale, modification, or transfer is permitted without the expressed agreement
from the author.

The client recognizes that this specific program is separate and distinct
from other code within this application that was completed under a work-for-hire
contract. It was copied into a client solution to deliver a functional product
with tested programs as efficiently as possible.
"""
import logging
import base64
import re
from pathlib import Path
from urllib3.exceptions import NewConnectionError
from lxml import etree
import requests
from . import xml_utilities, lookups

BASE_DIR = Path(__file__).resolve().parent


def update_pair_values(xml, dict_values):
    # Rewrite this so that it traverses the child nodes with the child dictionaries
    for key, value in dict_values.items():
        if isinstance(value, dict):
            update_pair_values(xml, value)
        elif isinstance(value, list):
            for each in value:
                update_pair_values(xml, each)
        else:
            expr = "//*[local-name() = $name]"
            try:
                xml.xpath(expr, name=key)[0].text = dict_values[key]
            except KeyError:
                pass
            except IndexError:
                pass
    return xml


def copy_object_for_update(object_type, in_xml):
    out_xml = etree.parse(f'{BASE_DIR}/xml/update_{object_type.lower()}.xml')
    objects = in_xml.findall(f'.//b:{object_type.capitalize()}', namespaces=xml_utilities.get_namespaces(in_xml))
    if len(objects) > 0:
        for each in objects:
            out_xml_element = out_xml.find(f'.//ns1:{object_type.capitalize()}Object', namespaces=xml_utilities.get_namespaces(out_xml))
            for element in each.getchildren():
                out_xml_element.append(etree.fromstring(etree.tostring(element)))
    return out_xml


class EpicSDK:
    endpoint_url = str()
    database = str()
    user_code = str()
    password = str()
    host = str()

    def __init__(self, endpoint_url, database, user_code, password, host):
        self.database = database
        self.password = password
        self.endpoint_url = endpoint_url
        self.host = host
        self.user_code = user_code

    def update_header(self, xml):
        nsmap = {
            'ns': 'http://schemas.appliedsystems.com/epic/sdk/2009/07/'
        }
        xml.find('.//ns:AuthenticationKey', namespaces=nsmap).text = self.password
        xml.find('.//ns:DatabaseName', namespaces=nsmap).text = self.database
        xml.find('.//ns:UserCode', namespaces=nsmap).text = self.user_code
        return xml

    def post_message(self, xml, method):
        xml = self.update_header(xml)
        xml = xml_utilities.clean_xml(xml)

        # print(etree.tostring(xml, pretty_print=True, method="html"))
        logging.debug(etree.tostring(xml, pretty_print=True, method="html"))

        if method == 'upload_attachment_file':
            endpoint = '/Attachments'
        else:
            endpoint = '/v2022_01'

        response = requests.post(url=f'{self.endpoint_url}{endpoint}',
                               data=etree.tostring(xml, encoding=None),
                               headers={
                                  'Accept-Encoding': 'gzip, deflate',
                                  'Content-Type': 'text/xml',
                                  'charset': 'UTF-8',
                                  'SOAPAction': lookups.soap_actions[method],
                                  'Host': self.host,
                                  'Connection': 'Keep-Alive',
                                  'User-Agent': 'Apache-HttpClient/4.5.5 (Java/16.0.1)'
                               })

        # print(response.text)
        logging.debug(response.text)

        return response.text

    def post_message_with_retry(self, xml, method):
        response = None
        while True:
            try:
                response = self.post_message(xml, method)
            except NewConnectionError as error:
                logging.error(error)
                logging.error(response)
                continue
            except OSError as error:
                logging.error(error)
                logging.error(response)
                continue
            break
        return response

    def get_object(self, object_type, search_criteria):
        method = f'get_{object_type.lower()}'
        xml = etree.parse(f'{BASE_DIR}/xml/{method}.xml')
        xml = self.update_header(xml)
        xml = update_pair_values(xml, search_criteria)
        response = self.post_message_with_retry(xml=xml, method=method)
        return response

    def update_object(self, object_type, in_xml, update_dict):
        method = f'update_{object_type.lower()}'
        xml = copy_object_for_update(object_type, in_xml)
        xml = update_pair_values(xml, update_dict)
        print(etree.tostring(xml))
        response = self.post_message_with_retry(xml=xml, method=method)
        return response

    def insert_object(self, model_type, insert_model):
        method = f'insert_{model_type.lower()}'
        xml = xml_utilities.dict_to_xml(model_type, insert_model, "insert")
        response = self.post_message_with_retry(xml=xml, method=method)
        return response

    def action_object(self, object_type, update_dict):
        method = f'action_{object_type.lower()}'
        xml = etree.parse(f'{BASE_DIR}/xml/{method}.xml')
        xml = self.update_header(xml)
        xml = update_pair_values(xml, update_dict)
        response = self.post_message_with_retry(xml=xml, method=method)
        return response

    def delete_object(self, object_type, update_dict):
        method = f'delete_{object_type.lower()}'
        xml = etree.parse(f'{BASE_DIR}/xml/{method}.xml')
        xml = self.update_header(xml)
        xml = update_pair_values(xml, update_dict)
        response = self.post_message_with_retry(xml=xml, method=method)
        return response

    def get_object_and_convert(self, object_type, search_criteria):
        method = f'get_{object_type.lower()}'
        xml = etree.parse(f'{BASE_DIR}/xml/{method}.xml')
        xml = self.update_header(xml)
        xml = update_pair_values(xml, search_criteria)
        response = self.post_message_with_retry(xml=xml, method=method)
        print(response)
        object_dict = xml_utilities.xml_to_dict(response, object_type)
        print(object_dict)

    def upload_attachment(self, attachment) -> str:
        temp_file = open(f'{attachment}', 'rb')
        upload = base64.encodebytes(temp_file.read())
        temp_file.close()
        xml = etree.parse(f'{BASE_DIR}/xml/upload_attachment_file.xml')
        root = xml.getroot()
        expr = "//*[local-name() = $name]"
        root.xpath(expr, name="FileDataStream")[0].text = upload
        response = self.post_message_with_retry(xml=xml, method='upload_attachment_file')
        temp_xml = etree.fromstring(re.search('<s:Envelope(.+?)</s:Envelope>', str(response)).group(0))
        expr = "//*[local-name() = $name]"
        ticket = temp_xml.xpath(expr, name=f'Upload_Attachment_FileResult')[0].text
        return ticket


def get_sdk_from_env(filename: str) -> EpicSDK:
    env = {}
    with open(filename, 'r') as env_file:
        for line in env_file.readlines():
            key = line.split('=', maxsplit=1)[0]
            value = line.split('=', maxsplit=1)[1].replace('\n', '')
            env[key] = value
    epic_sdk = EpicSDK(
        endpoint_url=env['EPIC_ENDPOINT'],
        database=env['EPIC_DATABASE'],
        user_code=env['EPIC_USER_CODE'],
        password=env['EPIC_PASSWORD'],
        host=env['EPIC_HOST']
    )
    return epic_sdk
