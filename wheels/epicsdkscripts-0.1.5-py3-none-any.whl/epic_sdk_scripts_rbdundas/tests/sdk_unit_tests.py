import os
import unittest
from pathlib import Path
from lxml import etree
from epic_sdk_scripts_rbdundas import epic_sdk, xml_utilities


class SDKTestCase(unittest.TestCase):
    def test_get_object(self):
        BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
        sdk = epic_sdk.get_sdk_from_env(f"{BASE_DIR}/.env")
        search_criteria = {"PolicyID": "358466"}
        xml = sdk.get_object("line", search_criteria)
        print(etree.tostring(etree.fromstring(xml), pretty_print=True, encoding="unicode"))
        self.assertIsNotNone(xml)

    def test_copy_for_update(self):
        in_xml = None
        xml = etree.fromstring(in_xml)
        element = xml.xpath(f"//*[local-name() = 'QuestionAnswers']")[0]
        self.assertIsNotNone(xml)
        
    def test_update_attachment_details(self):
        search_dict = {
            'AttachmentID': str(1479480)
        }
        BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
        sdk = epic_sdk.get_sdk_from_env(f"{BASE_DIR}/.env")
        attachment = sdk.get_object('Attachment', search_dict)
        xml = etree.fromstring(attachment)
        update_dict = {
            'Folder': 'ARC Accessible'
        }
        out_xml = epic_sdk.copy_object_for_update('Attachment', xml)
        print(etree.tostring(out_xml))
        self.assertIsNotNone(xml)

    def test_update_policy_commission(self):
        xml_string = b'<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><Get_LineResponse xmlns="http://webservices.appliedsystems.com/epic/sdk/2021/01/"><Get_LineResult xmlns:a="http://schemas.appliedsystems.com/epic/sdk/2017/02/_get/" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><a:Lines xmlns:b="http://schemas.appliedsystems.com/epic/sdk/2017/02/_account/_policy/"><b:Line><b:AgencyCommissionAmount i:nil="true"/><b:AgencyCommissionPercent>10.0000</b:AgencyCommissionPercent><b:AgencyCommissionType>%</b:AgencyCommissionType><b:AgencyDefinedCategoryItems xmlns:c="http://schemas.appliedsystems.com/epic/sdk/2009/07/_account/_common/"/><b:AgreementID>-1</b:AgreementID><b:AnnualizedCommission i:nil="true"/><b:AnnualizedPremium i:nil="true"/><b:BilledCommission i:nil="true"/><b:BilledPremium i:nil="true"/><b:BillingModeOption xmlns:c="http://schemas.appliedsystems.com/epic/sdk/2009/07/_common/"><c:OptionName>DirectBilled</c:OptionName><c:Value>1</c:Value></b:BillingModeOption><b:BillingValue xmlns:c="http://schemas.appliedsystems.com/epic/sdk/2017/02/_account/_policy/_line/"><c:BillBrokerNet>false</c:BillBrokerNet><c:BillingPlan/><c:FinancedFlag>false</c:FinancedFlag><c:InvoiceToAccountLookupCode>ROBSDOG-06</c:InvoiceToAccountLookupCode><c:InvoiceToAddress xmlns:d="http://schemas.appliedsystems.com/epic/sdk/2009/07/_shared/"><d:City>Fresno</d:City><d:CountryCode>USA</d:CountryCode><d:County/><d:StateOrProvinceCode>CA</d:StateOrProvinceCode><d:Street1>10451 N Pierpont Cir</d:Street1><d:Street2/><d:Street3/><d:ZipOrPostalCode>93730</d:ZipOrPostalCode></c:InvoiceToAddress><c:InvoiceToAddressDescription/><c:InvoiceToContactID>238975</c:InvoiceToContactID><c:InvoiceToContactName>Robert Dundas</c:InvoiceToContactName><c:InvoiceToDeliveryMethod>Mail</c:InvoiceToDeliveryMethod><c:InvoiceToEmail>rbdundas@gmail.com</c:InvoiceToEmail><c:InvoiceToFaxCountryCode/><c:InvoiceToFaxExtension/><c:InvoiceToFaxNumber/><c:InvoiceToSiteID/><c:InvoiceToType>Client</c:InvoiceToType><c:LoanNumber/><c:TaxOptionCode/></b:BillingValue><b:DefaultCommissionAgreement>false</b:DefaultCommissionAgreement><b:Downloaded i:nil="true"/><b:EstimatedCommission>150.00</b:EstimatedCommission><b:EstimatedMonthlyCommission i:nil="true"/><b:EstimatedMonthlyPremium i:nil="true"/><b:EstimatedMonthlyPremiumAsOfDate i:nil="true"/><b:EstimatedPremium>1500.00</b:EstimatedPremium><b:HistoryValue xmlns:c="http://schemas.appliedsystems.com/epic/sdk/2011/01/_account/_policy/_line/"><c:Comments/><c:DateFirstWritten>2024-07-16T00:00:00</c:DateFirstWritten><c:BrokerOfRecordDate i:nil="true"/></b:HistoryValue><b:IssuingCompanyLookupCode>TBDCO1</b:IssuingCompanyLookupCode><b:IssuingLocationCode>CA</b:IssuingLocationCode><b:LineGUID>3BC7EB82-355F-48BC-9143-52FA0784CAC5</b:LineGUID><b:LineID>370703</b:LineID><b:LineInformationLineID/><b:LineTypeCode>PAUT</b:LineTypeCode><b:LineTypeDescription>Personal Automobile</b:LineTypeDescription><b:PayableContractID i:nil="true"/><b:PolicyID>358479</b:PolicyID><b:PremiumPayableLookupCode>AMWINSI-01</b:PremiumPayableLookupCode><b:PremiumPayableTypeCode>BR</b:PremiumPayableTypeCode><b:ProducerBrokerCommissionsValue xmlns:c="http://schemas.appliedsystems.com/epic/sdk/2011/01/_account/_policy/_line/"><c:Commissions xmlns:d="http://schemas.appliedsystems.com/epic/sdk/2011/01/_account/_policy/_line/_producerbrokercommissions/"><d:CommissionItem><d:CommissionAmount i:nil="true"/><d:CommissionID>376029</d:CommissionID><d:CommissionPercent>85.0000</d:CommissionPercent><d:CommissionType>@</d:CommissionType><d:Flag>View</d:Flag><d:LookupCode>TAJUCAM-01</d:LookupCode><d:OrderNumber>0</d:OrderNumber><d:ProducerBrokerCode>BPAY</d:ProducerBrokerCode><d:ProductionCredit>100.0000</d:ProductionCredit><d:CommissionAgreementID>66451</d:CommissionAgreementID><d:ContractID>65953</d:ContractID><d:ContractName>Default Premium/Commission Payable Contract</d:ContractName><d:ShareRevenueAgencyCode/><d:ShareRevenueAgencyID>-1</d:ShareRevenueAgencyID><d:ShareRevenueAgencyName/><d:ShareRevenueBranchCode/><d:ShareRevenueBranchID>-1</d:ShareRevenueBranchID><d:ShareRevenueBranchName/><d:ShareRevenueDepartmentCode/><d:ShareRevenueDepartmentID>-1</d:ShareRevenueDepartmentID><d:ShareRevenueDepartmentName/><d:ShareRevenuePercent>0</d:ShareRevenuePercent><d:ShareRevenueProfitCenterCode/><d:ShareRevenueProfitCenterID>-1</d:ShareRevenueProfitCenterID><d:ShareRevenueProfitCenterName/><d:PrBrLineCommissionAnnualized i:nil="true"/><d:PrBrLineCommissionEstimated i:nil="true"/><d:OverrideCommissionAgreementPercentageOrAmount>false</d:OverrideCommissionAgreementPercentageOrAmount><d:UseCommissionAgreement>true</d:UseCommissionAgreement></d:CommissionItem></c:Commissions><c:ProducerBrokerCommissionTermOption xmlns:d="http://schemas.appliedsystems.com/epic/sdk/2009/07/_common/"><d:OptionName>SingleTermCommission</d:OptionName><d:Value>0</d:Value></c:ProducerBrokerCommissionTermOption><c:ProducerBrokerScheduleTermItems xmlns:d="http://schemas.appliedsystems.com/epic/sdk/2011/01/_account/_policy/_line/_producerbrokercommissions/"/></b:ProducerBrokerCommissionsValue><b:ProfitCenterCode>STA</b:ProfitCenterCode><b:RisksInsured i:nil="true"/><b:RisksInsuredDescription/><b:ServiceSummaries xmlns:c="http://schemas.appliedsystems.com/epic/sdk/2011/01/_account/_policy/_line/"><c:ServiceSummaryItem><c:Action>New</c:Action><c:Description>Personal Automobile</c:Description><c:EffectiveDate>2024-07-16T00:00:00</c:EffectiveDate><c:EnteredDate>2024-07-16T17:09:13.08</c:EnteredDate><c:ServiceSummaryID>449394</c:ServiceSummaryID><c:ServiceSummaryVersion>1</c:ServiceSummaryVersion><c:Stage>In Process</c:Stage><c:StageChangedDate i:nil="true"/></c:ServiceSummaryItem></b:ServiceSummaries><b:ServicingContacts xmlns:c="http://schemas.appliedsystems.com/epic/sdk/2009/07/_account/_common/"><c:ServicingRoleItem><c:Description>Branch Office</c:Description><c:EmployeeLookupCode>BRANC1</c:EmployeeLookupCode><c:Role>Account Manager</c:Role><c:Code>AM</c:Code></c:ServicingRoleItem><c:ServicingRoleItem><c:Description>Branch Office</c:Description><c:EmployeeLookupCode>BRANC1</c:EmployeeLookupCode><c:Role>Producer</c:Role><c:Code>PRO</c:Code></c:ServicingRoleItem><c:ServicingRoleItem><c:Description/><c:EmployeeLookupCode/><c:Role>Account Coordinator/Assistant</c:Role><c:Code>AC</c:Code></c:ServicingRoleItem><c:ServicingRoleItem><c:Description/><c:EmployeeLookupCode/><c:Role>Account Executive</c:Role><c:Code>AE</c:Code></c:ServicingRoleItem><c:ServicingRoleItem><c:Description/><c:EmployeeLookupCode/><c:Role>Senior Placement Specialist</c:Role><c:Code>SPS</c:Code></c:ServicingRoleItem><c:ServicingRoleItem><c:Description/><c:EmployeeLookupCode/><c:Role>Associate Placement Specialist</c:Role><c:Code>APS</c:Code></c:ServicingRoleItem><c:ServicingRoleItem><c:Description/><c:EmployeeLookupCode/><c:Role>Affiliate Sales Director</c:Role><c:Code>SLD</c:Code></c:ServicingRoleItem><c:ServicingRoleItem><c:Description/><c:EmployeeLookupCode/><c:Role>Affiliate Service Director</c:Role><c:Code>SVD</c:Code></c:ServicingRoleItem><c:ServicingRoleItem><c:Description/><c:EmployeeLookupCode/><c:Role>Affiliate Agency</c:Role><c:Code>AFF</c:Code></c:ServicingRoleItem></b:ServicingContacts><b:StatusCode>NEW</b:StatusCode><b:Timestamp>2024-07-16T17:10:59.067</b:Timestamp><b:TotalEligible i:nil="true"/><b:TotalEligibleDescription/><b:IgnoreAtLeastOnePrBrCommissionRequirement>false</b:IgnoreAtLeastOnePrBrCommissionRequirement><b:OverrideCommissionAgreementPercentageOrAmount>false</b:OverrideCommissionAgreementPercentageOrAmount><b:PlanOptionName/><b:IgnoreLineStatusCodeOnUpdate>false</b:IgnoreLineStatusCodeOnUpdate><b:PolicyDetailEngineID/></b:Line></a:Lines><a:TotalPages>1</a:TotalPages></Get_LineResult></Get_LineResponse></s:Body></s:Envelope>'
        xml = etree.fromstring(xml_string)
        out_xml = epic_sdk.copy_object_for_update('Line', xml)
        nsmap = xml_utilities.get_namespaces(out_xml)
        new_ci = etree.parse(f"commission_item.xml")
        new_ci = new_ci.getroot()
        commission_items = out_xml.findall(".//{http://schemas.appliedsystems.com/epic/sdk/2011/01/_account/_policy/_line/_producerbrokercommissions/}CommissionItem", namespaces=nsmap)
        for commission_item in commission_items:
            parent = commission_item.getparent()
            parent.remove(commission_item)
            parent.append(new_ci)
        print(etree.tostring(out_xml))
        self.assertIsNotNone(out_xml)

    def test_epic_action_renew_policy(self):
        BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
        sdk = epic_sdk.get_sdk_from_env(f"{BASE_DIR}/.env")
        policy = sdk.get_object('Policy', search_criteria={'PolicyID': '292342'})
        policy_xml = etree.fromstring(policy)
        lines = sdk.get_object('Line', search_criteria={'PolicyID': '292342'})
        lines_xml = etree.fromstring(lines)

        policies = xml_utilities.xml_to_dict(policy_xml, 'Policy')
        lines = xml_utilities.xml_to_dict(lines_xml, 'Line')

        # Change the Effective and Expiration Dates
        # Change the Policy Description. It is being overwritten by the Servicing Contacts Description

        line_items = []
        for line in lines:
            del line['Line']['ProducerBrokerCommissionsValue']['ProducerBrokerCommissionTermOption']
            line['Line']['AgencyCommissionTypeCode'] = line['Line'].pop('AgencyCommissionType')
            line['Line']['Flag'] = 'Renew'
            line_items.append({'LineItem': line['Line']})
            print(line)

        renew_object = {
            'RenewObject': policies[0]['Policy'],
            'Lines': line_items
        }

        result = sdk.action_object('Policy_Renew', renew_object)
        print(result)
        self.assertIsNotNone(result)

    def test_epic_upload_attachment(self):
        BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
        sdk = epic_sdk.get_sdk_from_env(f"{BASE_DIR}/.env")
        file_name = 'file.pdf'
        ticket = sdk.upload_attachment(file_name)
        print(ticket)
        self.assertIsNotNone(ticket)

    def test_epic_insert_attachment(self):
        BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
        sdk = epic_sdk.get_sdk_from_env(f"{BASE_DIR}/.env")
        file_name = 'file.pdf'
        ticket = '89aecd00-ff60-46dc-8a18-2247307c7dd4'
        file_stats = os.stat(file_name)
        file_detail_item = {
            'AttachmentObject': {
                'AccountID': '165655',
                'AccountTypeCode': 'CUST',
                'AgencyStructures': [
                    {'AgencyStructureItem': {'AgencyCode': 'PIA', 'BranchCode': 'AFF'}},
                ],
                'AttachedTos': [{
                    'AttachedToItem': {
                        'AttachedToID': str(292342),
                        'AttachedToType': 'Policy',
                        'Flag': 'Insert'
                    }
                }],
                'Description': 'MVR',
                'Files': [{
                    'FileDetailItem': {
                        'Extension': file_name.split('.')[1],
                        'FileName': file_name,
                        'Length': file_stats.st_size,
                        'TicketName': ticket,
                    }
                }],
                'Folder': 'ARC Accessible',
                'ClientAccessible': 'true'
            },
        }
        attachment = sdk.insert_object('attachment', file_detail_item)
        print(attachment)
        self.assertIsNotNone(attachment)



if __name__ == "__main__":
    unittest.main()
