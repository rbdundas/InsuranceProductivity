import unittest
from pathlib import Path
from lxml import etree
from epic_sdk_scripts_rbdundas import epic_sdk, xml_utilities


class XMLTestCase(unittest.TestCase):

    def setup(self):
        pass

    def test_client_xml_to_dict(self):
        client_xml = etree.parse('client.xml')
        client = xml_utilities.xml_to_dict(client_xml, 'Client')
        print(client)
        self.assertIsNotNone(client)

    def test_client_dict_to_xml(self):
        clients = [{'Client': {'AccountName': "ROB'S DOG SITTING", 'AccountValue': {'Address': {'City': 'Fresno', 'CountryCode': 'USA', 'StateOrProvinceCode': 'CA', 'Street1': '10451 N Pierpont Cir', 'ZipOrPostalCode': '93730'}, 'Comments': 'This is a second test.', 'Number': '5594921234', 'NumberCallPermission': 'Did Not Obtain', 'Structure': {'AgencyStructureItem': {'AgencyCode': 'PIA', 'BranchCode': 'AFF', 'Flag': 'View'}}, 'PhoneCountryCode': '1', 'AccountEmail': 'test@gmail.com'}, 'BillingValue': {'ServiceChargeFlag': 'false', 'InvoiceLayout': '* P&C Invoices', 'InvoicePageBreak': 'Client', 'StatementLayout': 'Default Client Statement', 'StatementPageBreak': 'Account', 'BillBrokerNet': 'false', 'CPAAuthorized': 'No'}, 'CategoriesHistoryValue': {'DateConverted': '2024-06-27T00:00:00', 'Relationships': {'RelationshipItem': {'Flag': 'View', 'IfRelatedAccountTypeIsClientIsProspect': 'false', 'RelatedAccountLookupCode': 'TAJUCAM-01', 'RelatedAccountType': 'BROK', 'RelationshipID': '141502', 'RelationshipRole': 'Affiliate Broker', 'RelationshipType': 'Epic Affiliate Broker/Client'}}}, 'ClientID': '202121', 'ClientLookupCode': 'ROBSDOG-06', 'ConfidentialClientAccessValue': {'ConfidentialClientAccessAllSelectedOption': {'OptionName': 'All', 'Value': '0'}}, 'FormatOption': {'OptionName': 'Business', 'Value': '1'}, 'InActivateOption': {'OptionName': 'DoNothing', 'Value': '0'}, 'IsBenefits': 'false', 'IsBonds': 'false', 'IsCommercial': 'true', 'IsFinancialServices': 'false', 'IsLifeAndHealth': 'false', 'IsOther': 'false', 'IsPersonal': 'true', 'IsProspectFlag': 'false', 'ServicingContacts': [{'ServicingRoleItem': {'Description': 'Branch Office', 'EmployeeLookupCode': 'BRANC1', 'Role': 'Account Manager', 'Code': 'AM'}}, {'ServicingRoleItem': {'Description': 'Branch Office', 'EmployeeLookupCode': 'BRANC1', 'Role': 'Producer', 'Code': 'PRO'}}, {'ServicingRoleItem': {'Role': 'Account Coordinator/Assistant', 'Code': 'AC'}}, {'ServicingRoleItem': {'Role': 'Account Executive', 'Code': 'AE'}}, {'ServicingRoleItem': {'Role': 'Benefits Account Manager', 'Code': 'BAM'}}, {'ServicingRoleItem': {'Role': 'Benefits Producer', 'Code': 'BPR'}}, {'ServicingRoleItem': {'Role': 'Benefits Executive', 'Code': 'BEX'}}, {'ServicingRoleItem': {'Role': 'Benefits Associate', 'Code': 'BAS'}}, {'ServicingRoleItem': {'Role': 'Senior Placement Specialist', 'Code': 'SPS'}}, {'ServicingRoleItem': {'Role': 'Associate Placement Specialist', 'Code': 'APS'}}, {'ServicingRoleItem': {'Role': 'Affiliate Sales Director', 'Code': 'SLD'}}, {'ServicingRoleItem': {'Role': 'Affiliate Service Director', 'Code': 'SVD'}}, {'ServicingRoleItem': {'Role': 'Affiliate Agency', 'Code': 'AFF'}}], 'Timestamp': '2024-07-16T17:48:53.673', 'IsAgriculture': 'false', 'ClientGUID': '00a416e3-f237-4b6e-b922-ffc8ba9481d6', 'DoNotPurge': 'true', 'EmployeeBenefitsValue': {}}}]
        client = clients[0]
        client_xml = xml_utilities.dict_to_xml('Client', client, 'insert')
        print(etree.tostring(client_xml, pretty_print=True, encoding="unicode"))
        self.assertIsNotNone(client_xml)


if __name__ == "__main__":
    unittest.main()
